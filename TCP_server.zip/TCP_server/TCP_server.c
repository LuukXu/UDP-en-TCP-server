#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <stdint.h>
 
#pragma comment(lib, "ws2_32.lib")
 
#define PORT     5006
#define BACKLOG  5
 
int main(void) {
    /* ── Winsock initialiseren ── */
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        fprintf(stderr, "WSAStartup mislukt: %d\n", WSAGetLastError());
        return 1;
    }
 
    srand((unsigned)time(NULL));
 
    /* ── Server-socket aanmaken ── */
    SOCKET server_sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (server_sock == INVALID_SOCKET) {
        fprintf(stderr, "socket() fout: %d\n", WSAGetLastError());
        WSACleanup(); return 1;
    }
 
    /* SO_REUSEADDR zodat we snel opnieuw kunnen binden */
    int opt = 1;
    setsockopt(server_sock, SOL_SOCKET, SO_REUSEADDR,
               (const char *)&opt, sizeof(opt));
 
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family      = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port        = htons(PORT);
 
    if (bind(server_sock, (struct sockaddr *)&server_addr,
             sizeof(server_addr)) == SOCKET_ERROR) {
        fprintf(stderr, "bind() fout: %d\n", WSAGetLastError());
        closesocket(server_sock); WSACleanup(); return 1;
    }
 
    if (listen(server_sock, BACKLOG) == SOCKET_ERROR) {
        fprintf(stderr, "listen() fout: %d\n", WSAGetLastError());
        closesocket(server_sock); WSACleanup(); return 1;
    }
 
    printf("TCP-server 'Hoger/Lager' gestart op poort %d\n", PORT);
    printf("Wacht op verbindingen...\n");
 
    /* ── Hoofdlus: één client per keer ── */
    for (;;) {
        struct sockaddr_in client_addr;
        int addr_len = sizeof(client_addr);
 
        SOCKET client_sock = accept(server_sock,
                                    (struct sockaddr *)&client_addr,
                                    &addr_len);
        if (client_sock == INVALID_SOCKET) {
            fprintf(stderr, "accept() fout: %d\n", WSAGetLastError());
            continue;
        }
 
        printf("\n[+] Client verbonden: %s:%d\n",
               inet_ntoa(client_addr.sin_addr),
               ntohs(client_addr.sin_port));
 
        /* ── Geheim getal genereren ── */
        int secret = rand() % 100 + 1;
        printf("    Geheim getal: %d\n", secret);
 
        /* ── Spelloop voor deze client ── */
        int spel_actief = 1;
        while (spel_actief) {
 
            /* Ontvang precies 4 bytes (32-bit integer, network-byte-order) */
            uint32_t net_val = 0;
            int      bytes_ontvangen = 0;
            char    *buf = (char *)&net_val;
 
            while (bytes_ontvangen < 4) {
                int n = recv(client_sock,
                             buf + bytes_ontvangen,
                             4 - bytes_ontvangen, 0);
                if (n <= 0) {
                    /* Client heeft verbinding verbroken */
                    printf("    Client verbroken verbinding.\n");
                    spel_actief = 0;
                    break;
                }
                bytes_ontvangen += n;
            }
 
            if (!spel_actief) break;
 
            /* Network-byte-order → host-byte-order */
            int guess = (int)ntohl(net_val);
            printf("    Ontvangen gok: %d\n", guess);
 
            /* ── Vergelijken en antwoorden ── */
            const char *antwoord;
            if (guess < secret)
                antwoord = "Hoger\n";
            else if (guess > secret)
                antwoord = "Lager\n";
            else
                antwoord = "Correct\n";
 
            printf("    Antwoord: %s", antwoord);
 
            int sent = send(client_sock, antwoord, (int)strlen(antwoord), 0);
            if (sent == SOCKET_ERROR) {
                fprintf(stderr, "    send() fout: %d\n", WSAGetLastError());
                break;
            }
 
            /* Bij "Correct" → verbinding verbreken en nieuw spel starten */
            if (guess == secret) {
                printf("    Correct geraden! Verbinding verbroken.\n");
                spel_actief = 0;
            }
        }
 
        closesocket(client_sock);
        printf("[-] Client losgekoppeld. Wacht op volgende speler...\n");
    }
 
    closesocket(server_sock);
    WSACleanup();
    return 0;
}